# Market Power Simulator

An interactive Streamlit app to simulate different market structures:
- Perfect Competition
- Monopoly
- Monopsony

Adjust supply and demand parameters using sliders and visualize the effect on price, quantity, and efficiency.
